( function( $ ) {

	"use strict";

	// create an element to run tests inside
	var $testCanvas = $( "<div id='testCanvas'></div>" );

	$( "body" ).prepend( $testCanvas );

}( jQuery ) );
